## PaymentFormModalComponent

form for adding new patient

### Usage

```javascript
import PaymentFormModalComponent from 'components/PaymentFormModalComponent/PaymentFormModalComponent.js';
```
