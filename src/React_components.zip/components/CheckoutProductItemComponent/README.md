## CheckoutProductItemComponent

Product item checkout page

### Usage

```javascript
import CheckoutProductItemComponent from 'components/CheckoutProductItemComponent/CheckoutProductItemComponent.js';
```
