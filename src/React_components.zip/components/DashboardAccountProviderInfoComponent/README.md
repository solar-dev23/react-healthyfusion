## DashboardAccountProviderInfoComponent

Dashboard account provider info

### Usage

```javascript
import DashboardAccountProviderInfoComponent from 'components/DashboardAccountProviderInfoComponent/DashboardAccountProviderInfoComponent.js';
```
