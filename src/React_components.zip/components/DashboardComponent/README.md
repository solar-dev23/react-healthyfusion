## DashboardComponent

Dashboard component

### Usage

```javascript
import DashboardComponent from 'components/DashboardComponent/DashboardComponent.js';
```
