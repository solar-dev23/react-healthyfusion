## DashboardHeaderComponent

Header of dashboard

### Usage

```javascript
import DashboardHeaderComponent from 'components/DashboardHeaderComponent/DashboardHeaderComponent.js';
```
