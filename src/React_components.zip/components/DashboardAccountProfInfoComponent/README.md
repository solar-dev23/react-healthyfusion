## DashboardAccountProfInfoComponent

Account prof info

### Usage

```javascript
import DashboardAccountProfInfoComponent from 'components/DashboardAccountProfInfoComponent/DashboardAccountProfInfoComponent.js';
```
