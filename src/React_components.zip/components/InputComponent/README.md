## InputComponent

Input

### Usage

```javascript
import InputComponent from 'components/InputComponent/InputComponent.js';
```
