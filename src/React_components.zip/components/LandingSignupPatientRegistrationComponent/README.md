## LandingSignupPatientRegistrationComponent

step2 of patient registration

### Usage

```javascript
import LandingSignupPatientRegistrationComponent from 'components/LandingSignupPatientRegistrationComponent/LandingSignupPatientRegistrationComponent.js';
```
