## AddPatientFormComponent

Add patient form 

### Usage

```javascript
import AddPatientFormComponent from 'components/AddPatientFormComponent/AddPatientFormComponent.js';
```
