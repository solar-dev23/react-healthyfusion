## DashboardFooterComponent

Dashboard pages footer

### Usage

```javascript
import DashboardFooterComponent from 'components/DashboardFooterComponent/DashboardFooterComponent.js';
```
