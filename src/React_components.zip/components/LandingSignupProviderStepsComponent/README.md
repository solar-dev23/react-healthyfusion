## LandingSignupProviderStepsComponent

Steps of provider registration

### Usage

```javascript
import LandingSignupProviderStepsComponent from 'components/LandingSignupProviderStepsComponent/LandingSignupProviderStepsComponent.js';
```
