## PatientShippingDetailsComponent

Shipping Details patient

### Usage

```javascript
import PatientShippingDetailsFormComponent from 'components/PatientShippingDetailsFormComponent/PatientShippingDetailsFormComponent.js';
```
