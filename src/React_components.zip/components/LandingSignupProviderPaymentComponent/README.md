## LandingSignupProviderPaymentComponent

Payment step of provider registration

### Usage

```javascript
import LandingSignupProviderPaymentComponent from 'components/LandingSignupProviderPaymentComponent/LandingSignupProviderPaymentComponent.js';
```
