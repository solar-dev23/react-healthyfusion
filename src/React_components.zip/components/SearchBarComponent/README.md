## SearchBarComponent

Search bar component

### Usage

```javascript
import SearchBarComponent from 'components/SearchBarComponent/SearchBarComponent.js';
```
