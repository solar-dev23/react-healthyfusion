## LandingSignupProviderBusinessComponent

Step 2 business of provider registration

### Usage

```javascript
import LandingSignupProviderBusinessComponent from 'components/LandingSignupProviderBusinessComponent/LandingSignupProviderBusinessComponent.js';
```
