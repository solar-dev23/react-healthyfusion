## DashboardAccountPatientInfoComponent

Patient info

### Usage

```javascript
import DashboardAccountPatientInfoComponent from 'components/DashboardAccountPatientInfoComponent/DashboardAccountPatientInfoComponent.js';
```
