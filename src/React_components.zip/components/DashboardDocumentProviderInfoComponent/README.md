## DashboardDocumentProviderInfoComponent

Dashboard account provider info

### Usage

```javascript
import DashboardDocumentProviderInfoComponent from 'components/DashboardDocumentProviderInfoComponent/DashboardDocumentProviderInfoComponent.js';
```
