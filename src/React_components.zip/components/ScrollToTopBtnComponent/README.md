## ScrollToTopBtnComponent

Fixed button for scrolling to top at long pages

### Usage

```javascript
import ScrollToTopBtnComponent from 'components/ScrollToTopBtnComponent/ScrollToTopBtnComponent.js';
```
