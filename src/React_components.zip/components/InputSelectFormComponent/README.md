## InputSelectFormComponent

select input form 

### Usage

```javascript
import InputSelectFormComponent from 'components/InputSelectFormComponent/InputSelectFormComponent.js';
```
