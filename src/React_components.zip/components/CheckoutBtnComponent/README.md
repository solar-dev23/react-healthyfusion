## CheckoutBtnComponent

Check out button with dropdown

### Usage

```javascript
import CheckoutBtnComponent from 'components/CheckoutBtnComponent/CheckoutBtnComponent.js';
```
