## NavigationLinksComponent

Link pages navigation

### Usage

```javascript
import NavigationLinksComponent from 'components/NavigationLinksComponent/NavigationLinksComponent.js';
```
