## MonographComponent

Monograph

### Usage

```javascript
import MonographComponent from 'components/MonographComponent/MonographComponent.js';
```
