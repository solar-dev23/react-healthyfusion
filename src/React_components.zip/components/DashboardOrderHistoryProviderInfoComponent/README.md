## DashboardOrderHistoryProviderInfoComponent

Dashboard account provider info

### Usage

```javascript
import DashboardOrderHistoryProviderInfoComponent from 'components/DashboardOrderHistoryProviderInfoComponent/DashboardOrderHistoryProviderInfoComponent.js';
```
