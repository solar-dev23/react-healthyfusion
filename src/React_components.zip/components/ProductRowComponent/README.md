## ProductRowComponent

Row for products list

### Usage

```javascript
import ProductRowComponent from 'components/ProductRowComponent/ProductRowComponent.js';
```
