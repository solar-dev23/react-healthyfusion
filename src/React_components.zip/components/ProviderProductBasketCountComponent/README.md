## ProviderProductBasketCountComponent

Icon count cart of provider product basket 

### Usage

```javascript
import ProviderProductBasketCountComponent from 'components/ProviderProductBasketCountComponent/ProviderProductBasketCountComponent.js';
```
