## SectionComponent

Section component

### Usage

```javascript
import SectionComponent from 'components/SectionComponent/SectionComponent.js';
```
