## LandingSignupPatientComponent

Patient registartion 

### Usage

```javascript
import LandingSignupPatientComponent from 'components/LandingSignupPatientComponent/LandingSignupPatientComponent.js';
```
