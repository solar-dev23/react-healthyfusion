## ProviderProductsBasketPatientsComponent

Patients manipulation in provider products basket 

### Usage

```javascript
import ProviderProductsBasketPatientsComponent from 'components/ProviderProductsBasketPatientsComponent/ProviderProductsBasketPatientsComponent.js';
```
