## PatientPersonalInfoFormComponent

Info of patient form

### Usage

```javascript
import PatientPersonalInfoFormComponent from 'components/PatientPersonalInfoFormComponent/PatientPersonalInfoFormComponent.js';
```
