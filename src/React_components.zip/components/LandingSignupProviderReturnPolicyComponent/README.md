## LandingSignupProviderReturnPolicyComponent

include return policy information, step 5 provider registration

### Usage

```javascript
import LandingSignupProviderReturnPolicyComponent from 'components/LandingSignupProviderReturnPolicyComponent/LandingSignupProviderReturnPolicyComponent.js';
```
