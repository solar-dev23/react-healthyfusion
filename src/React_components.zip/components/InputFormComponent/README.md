## InputFormComponent

Input form componennt 

### Usage

```javascript
import InputFormComponent from 'components/InputFormComponent/InputFormComponent.js';
```
