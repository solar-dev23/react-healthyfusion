## LandingContentInfoComponent

Info on landing page

### Usage

```javascript
import LandingContentInfoComponent from 'components/LandingContentInfoComponent/LandingContentInfoComponent.js';
```
