## DashboardSortingComponent

Content sorting tools for dashboard

### Usage

```javascript
import DashboardSortingComponent from 'components/DashboardSortingComponent/DashboardSortingComponent.js';
```
