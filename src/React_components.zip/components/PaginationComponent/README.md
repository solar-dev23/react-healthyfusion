## PaginationComponent

Pagination

### Usage

```javascript
import PaginationComponent from 'components/PaginationComponent/PaginationComponent.js';
```
