## LandingSignupProviderSalesPolicyComponent

include sales policy information, step 4 provider registration

### Usage

```javascript
import LandingSignupProviderSalesPolicyComponent from 'components/LandingSignupProviderSalesPolicyComponent/LandingSignupProviderSalesPolicyComponent.js';
```
