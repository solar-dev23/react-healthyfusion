## LandingSignupProviderComponent

Proivder registration component from landing

### Usage

```javascript
import LandingSignupProviderComponent from 'components/LandingSignupProviderComponent/LandingSignupProviderComponent.js';
```
