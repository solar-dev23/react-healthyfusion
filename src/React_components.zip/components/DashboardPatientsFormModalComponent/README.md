## DashboardPatientsFormComponent

form for adding new patient

### Usage

```javascript
import DashboardPatientsFormComponent from 'components/DashboardPatientsFormComponent/DashboardPatientsFormModalComponent.js';
```
