## AccountPatientShippingComponent

Shipping Component patient account page

### Usage

```javascript
import AccountPatientShippingComponent from 'components/AccountPatientShippingComponent/AccountPatientShippingComponent.js';
```
