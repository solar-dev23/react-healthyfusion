## NavigationUserBlockComponent

User block nav component

### Usage

```javascript
import NavigationUserBlockComponent from 'components/NavigationUserBlockComponent/NavigationUserBlockComponent.js';
```
