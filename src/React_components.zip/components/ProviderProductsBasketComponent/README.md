## ProviderProductsBasketComponent

Provider products basket

### Usage

```javascript
import ProviderProductsBasketComponent from 'components/ProviderProductsBasketComponent/ProviderProductsBasketComponent.js';
```
