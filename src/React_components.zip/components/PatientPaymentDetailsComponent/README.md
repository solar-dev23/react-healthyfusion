## PatientPaymentDetailsComponent

Payment details of patient

### Usage

```javascript
import PatientPaymentDetailsComponent from 'components/PatientPaymentDetailsComponent/PatientPaymentDetailsComponent.js';
```
