## ChangePasswordFormComponent

Change password form

### Usage

```javascript
import ChangePasswordFormComponent from 'components/ChangePasswordFormComponent/ChangePasswordFormComponent.js';
```
