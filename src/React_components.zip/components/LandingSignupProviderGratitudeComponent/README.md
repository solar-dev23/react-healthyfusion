## LandingSignupProviderGratitudeComponent

step 7 of provider signup 

### Usage

```javascript
import LandingSignupProviderGratitudeComponent from 'components/LandingSignupProviderGratitudeComponent/LandingSignupProviderGratitudeComponent.js';
```
