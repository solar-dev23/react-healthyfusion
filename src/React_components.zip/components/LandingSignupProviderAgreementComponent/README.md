## LandingSignupProviderAgreementComponent

include agreement block, step 3 registration provider

### Usage

```javascript
import LandingSignupProviderAgreementComponent from 'components/LandingSignupProviderAgreementComponent/LandingSignupProviderAgreementComponent.js';
```
