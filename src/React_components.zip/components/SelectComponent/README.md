## SelectComponent

Select component

### Usage

```javascript
import SelectComponent from 'components/SelectComponent/SelectComponent.js';
```
