import React from 'react';

import './__NAME__.scss'

export default class __NAME__ extends React.Component {
    render() {
        return (
            <div className="__NAME-PARAMCASE__"></div>
        );
    }
}
