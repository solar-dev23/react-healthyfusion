## PaginationItemPageComponent

Page of pagination

### Usage

```javascript
import PaginationItemPageComponent from 'components/PaginationItemPageComponent/PaginationItemPageComponent.js';
```
