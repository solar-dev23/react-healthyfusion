## ModalComponent

component for modals

### Usage

```javascript
import ModalComponent from 'components/ModalComponent/ModalComponent.js';
```
