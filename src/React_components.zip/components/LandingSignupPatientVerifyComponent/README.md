## LandingSignupPatientVerifyComponent

Patient verify signup component from landing

### Usage

```javascript
import LandingSignupPatientVerifyComponent from 'components/LandingSignupPatientVerifyComponent/LandingSignupPatientVerifyComponent.js';
```
